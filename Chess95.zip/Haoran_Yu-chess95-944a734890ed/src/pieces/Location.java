package pieces;

/**
 * This class is location on board
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public class Location{
	public static int BOARDSIZE = 8;
	int x;
	int y;
	/**
	 * Constructor of Location
	 * 
	 * @param x The value of x axis
	 * @param y The value of y axis
	 */
	public Location(int x, int y) {
		this.x = x;
		this.y = y;
	}
	/**
	 * Get constructor x
	 * 
	 * @return x location
	 */
	public int getX() {
		return x;
	}
	/**
	 * Get constructor y
	 * 
	 * @return y location
	 */
	public int getY() {
		return y;
	}
	/**
	 * Equal function of x axis and y axis
	 * 
	 * @param location The location we want to compare
	 * @return The location is false or true
	 */
	public boolean equals(Location location) {
		return this.x==location.x && this.y == location.y;
	}
	
	/**
	 * To string the location
	 * @return The string of the location
	 */
	public String toString() {
		return "(" + x + " " + y +") ";
	}
}
