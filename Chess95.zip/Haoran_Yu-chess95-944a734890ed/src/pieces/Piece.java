package pieces;
import java.util.List;
import java.util.ArrayList;
import board.Board;
/**
 * This class is give variables and function to define every pieces
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public abstract class Piece {

	private Location location; 
	private List<Location> nextAvailableMoves = new ArrayList<>();
	private List<Location> attackRange = new ArrayList<>();
	private boolean isBlack;
	public String symbol;
	private boolean enpassant = false;
	/**
	 * Constructor of Piece
	 * 
	 * @param location The location of pieces
	 * @param isBlack The pieces' color
	 * @param symbol Pieces' symbol
	 */
	public Piece(Location location, boolean isBlack, String symbol) {
		this.location = location;
		this.isBlack = isBlack;
		this.symbol = symbol;
	}
	/**
	 * Get the boolean of black or not
	 * 
	 * @return Return true if is black piece or false is not
	 */
	public boolean isBlack() {
		return isBlack;
	}
	/**
	 * Get location 
	 * 
	 * @return Location
	 */
	public Location getLocation() {
		return location;
	}
	/**
	 * Get boolean enpassant
	 * 
	 * @return Enpassant boolean
	 */
	public boolean getEnpassant() {
		return enpassant;
	}
	/**
	 * Add next location to next move
	 * 
	 * @param location This location
	 */
	public void addNextAvailableMoves(Location location) {
		nextAvailableMoves.add(location);
	}
	/**
	 * Add location of attack range
	 *  
	 * @param location This location
	 */
	public void addAttackRange(Location location) {
		attackRange.add(location);
	}
	/**
	 * Get available location to move
	 * @return List of nextAvailableMoves
	 */
	public List<Location> getNextAvailableMoves() {
		return nextAvailableMoves;
	}
	/**
	 * Judge the moving is valid or not
	 * 
	 * @param location This location
	 * @return Return true is available move or false is not
	 */
	public boolean isAvailableMove(Location location) {
		for(int i = 0; i < nextAvailableMoves.size(); i ++ ) {
			if(location.equals(nextAvailableMoves.get(i))){
				return true;
			}
		}
		return false;
	}
	/**
	 * To string the all of white and black pieces 
	 * @return The string of white and black plus pieces' symbol
	 */
	public String toString() {
		if (isBlack) {
			return "b"+symbol;
		} else {
			return "w"+symbol;
		}
	}
	/**
	 * Set a abstract method which for calculate certain piece where can it move
	 * 
	 * @param pieces This side piece
	 * @param enemyPieces The other side 's piece
	 */
	public abstract void calculateAllAvailableMoves(List<Piece> pieces, List<Piece> enemyPieces);
	/**
	 * Clear two array list of nextAvailableMoves and attackRange
	 */
	public void clearNextAvailableMoves() {
		nextAvailableMoves = new ArrayList<>();
		attackRange = new ArrayList<>();
	}
	/**
	 * Piece real moving 
	 * 
	 * @param location This location 
	 * @param board This board
	 */
	public void move(Location location, Board board) {
		board.clear(this.location);
		this.location = location;
		board.setPiece(this);
	}
	/**
	 * Piece fake moving, use in check mate
	 * 
	 * @param location This location 
	 * @param board This board
	 */
	public void fakeMove(Location location, Board board) {
		board.clear(this.location);
		this.location = location;
		board.setPiece(this);
	}
	/**
	 * The function for castle between rook and king 
	 * 
	 * @return false
	 */
	public boolean canCastle() {
		return false;
	}
	/**
	 * To judge certain location has piece or not
	 * 
	 * @param location This location
	 * @param pieces All pieces
	 * @return Return true if there is piece or false is not
	 */
	static public boolean hasPiece(Location location, List<Piece> pieces) {
		for(int i = 0; i < pieces.size(); i++) {
			if(location.equals(pieces.get(i).getLocation())){
				return true;
			}
		}
		return false;
	}
	/**
	 * Get the list of attack range
	 * 
	 * @return List of attackRange
	 */
	public List<Location> getAttackRange() {
		return attackRange;
		
	}
	/**
	 * To judge certain piece in attack rage or not 
	 * 
	 * @param location This location
	 * @param enemyPieces The enemy team pieces
	 * @param pieces This team pieces
	 * @return Return true if this location is in attack range or false is not
	 */
	public static boolean inAttackRange(Location location, List<Piece> enemyPieces, List<Piece> pieces) {
		for(int i = 0; i < enemyPieces.size(); i++) {
			for(int j = 0; j < enemyPieces.get(i).getAttackRange().size();j++) {
				if(location.equals(enemyPieces.get(i).getAttackRange().get(j))) {
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * Check can this team block the way of check
	 * 
	 * @param location This location
	 * @param Pieces This team pieces
	 * @return Return true this location is in block range or false is not
	 */
	public static boolean inBlockRange(Location location, List<Piece> Pieces) {
		for(int i = 0; i < Pieces.size(); i++) {
			if(Pieces.get(i) instanceof King) {
				continue;
			}
			for(int j = 0; j < Pieces.get(i).getNextAvailableMoves().size();j++) {
				if(location.equals(Pieces.get(i).getNextAvailableMoves().get(j))) {
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * Set boolean enpassant true of false
	 * @param setEnpassant Set boolean
	 */
	public void setEnpassant(boolean setEnpassant) {
		enpassant = setEnpassant;
	}
	
	/**
	 * 
	 * Check if the location has piece that can enpassant kill
	 * 
	 * @param location This location
	 * @param enemyPieces The enemy team pieces
	 * @return Return true if the location has piece that can enpassant kill of false is not
	 */
	static public boolean hasEnpassantPawn(Location location, List<Piece> enemyPieces) {
		for(int i = 0; i < enemyPieces.size(); i++) {
			if(location.equals(enemyPieces.get(i).getLocation())){
				if(enemyPieces.get(i) instanceof Pawn && enemyPieces.get(i).getEnpassant()) {
					return true;
				}				
			}
		}
		return false;
	}
	
}
