package pieces;

import java.util.List;
/**
 * The class is to define queen pieces
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public class Queen extends Piece{
	/**
	 * Constructor of Queen
	 * 
	 * @param location This location 
	 * @param isBlack Check pieces is black or not
	 */
	public Queen(Location location, boolean isBlack) {
		super(location, isBlack, "Q");
	}
	/**
	 * An abstract method to get all available location can move
	 */
	public void calculateAllAvailableMoves(List<Piece> pieces, List<Piece> enemyPieces) {
		super.clearNextAvailableMoves();
		int x = super.getLocation().getX();
		int y = super.getLocation().getY();
		findAvailableMovesByDirection(x, y, 0, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, 0, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, 0, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 0, -1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, -1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y,-1, -1, pieces, enemyPieces);
	}
	/**
	 * Finding next available location to move
	 * 
	 * @param x The value of x axis
	 * @param y The value of y axis
	 * @param xD Move direction on x axis
	 * @param yD Move direction on y axis
	 * @param pieces This team pieces
	 * @param enemyPieces The enemy team pieces
	 */
	private void findAvailableMovesByDirection(int x, int y, int xD, int yD, List<Piece> pieces, List<Piece> enemyPieces) {
		x += xD;
		y += yD;
		while(0 <= x && x < Location.BOARDSIZE && 0 <= y && y < Location.BOARDSIZE) {
			Location curLocation = new Location(x,y);
			super.addAttackRange(curLocation);
			if(hasPiece(curLocation, pieces)) {
				break;
			} else {
				super.addNextAvailableMoves(curLocation);
				if(hasPiece(curLocation, enemyPieces)) {
					break;
				}
				
			}
			x += xD;
			y += yD;
		}
	}
}
