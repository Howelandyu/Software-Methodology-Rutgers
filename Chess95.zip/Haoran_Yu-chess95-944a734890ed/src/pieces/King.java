package pieces;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import board.Board;
/**
 * The class is to define king pieces
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public class King extends Piece{
	private boolean hasCastled = false;
	private boolean hasMoved = false;
	private Map<Location, Piece> castleMap = new HashMap<Location,Piece>(); 
	/**
	 * Constructor of King
	 * 
	 * @param location This location 
	 * @param isBlack Check pieces is black or not
	 */
	public King(Location location, boolean isBlack) {
		super(location, isBlack, "K");
	}
	/**
	 * An abstract method to get all available location can move
	 */
	public void calculateAllAvailableMoves(List<Piece> pieces, List<Piece> enemyPieces) {
		super.clearNextAvailableMoves();
		int x = super.getLocation().getX();
		int y = super.getLocation().getY();
		findAvailableMovesByDirection(x, y, 1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, -1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, -1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 0, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, 0, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, 0, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 0, -1, pieces, enemyPieces);
		canCastle(x, y, pieces, enemyPieces);
	}
	/**
	 * Finding next available location to move
	 * 
	 * @param x The value of x axis
	 * @param y The value of y axis
	 * @param xD Move direction on x axis
	 * @param yD Move direction on y axis
	 * @param pieces This team pieces
	 * @param enemyPieces The enemy team pieces
	 */
	private void findAvailableMovesByDirection(int x, int y, int xD, int yD, List<Piece> pieces, List<Piece> enemyPieces) {
		x += xD;
		y += yD;
		if(0 <= x && x < Location.BOARDSIZE && 0 <= y && y < Location.BOARDSIZE) {
			Location curLocation = new Location(x,y);
			if(!super.inAttackRange(curLocation, enemyPieces, pieces)) {
				super.addAttackRange(curLocation);
				if(hasPiece(curLocation, pieces)) {
					return;
				} else {
					super.addNextAvailableMoves(curLocation);
				}
			}
		}
	}
	/**
	 * The special move function for king
	 * 
	 * @param location The location that we want to move
	 * @param board This game board
	 */
	public void move(Location location, Board board) {
		super.move(location, board);
		this.hasMoved = true;
		 for (Map.Entry<Location,Piece> entry : castleMap.entrySet()) {
			 if(location.equals(entry.getKey())) {
				 Piece rookPiece = castleMap.get(entry.getKey());
				 int x = super.getLocation().getX();
				 if((rookPiece.getLocation().getX()> x) && (!hasCastled)) {
					 rookPiece.move(new Location(x - 1, getLocation().getY()), board);
				 } else if(!hasCastled) {
					 rookPiece.move(new Location(x + 1, getLocation().getY()), board);
				 }
				 hasCastled = true;
				 return;
			 }
		 }
	}
	/**
	 * It is a method to made castle when the king satisfy castle condition
	 * 
	 * @param x The value of x axis
	 * @param y The value of y axis
	 * @param pieces This team pieces
	 * @param enemyPieces The enemy team pieces
	 */
	private void canCastle(int x, int y, List<Piece> pieces, List<Piece> enemyPieces) {
		if(hasCastled || hasMoved) {
			return;
		}
		for(int i = 0; i < pieces.size(); i ++) {
			if(pieces.get(i) instanceof Rook && pieces.get(i).canCastle()) {
				int rookX = pieces.get(i).getLocation().getX();
				Location loc = new Location(x, y);
				if(inAttackRange(loc, enemyPieces, pieces)) {
					continue;
				}
				if(rookX > x) {
					loc = new Location(x + 1, y);
					if(inAttackRange(loc, enemyPieces, pieces) || hasPiece(loc, pieces)) {
						continue;
					}
					
					loc = new Location(x + 2, y);
					if(inAttackRange(loc, enemyPieces, pieces) || hasPiece(loc, pieces)) {
						continue;
					}
					
					if (x + 3 < rookX) {
						loc = new Location(x + 3, y);
						if(hasPiece(loc, pieces)) {
							continue;
						}
					}
					Location nextMove = new Location(x + 2, y);
					super.addNextAvailableMoves(nextMove);
					this.castleMap.put(nextMove,  pieces.get(i));
				} else {
					loc = new Location(x - 1, y);
					if(inAttackRange(loc, enemyPieces, pieces) || hasPiece(loc, pieces)) {
						continue;
					}
					
					loc = new Location(x - 2, y);
					if(inAttackRange(loc, enemyPieces, pieces) || hasPiece(loc, pieces)) {
						continue;
					}
					
					if (x - 3 > rookX) {
						loc = new Location(x - 3, y);
						if(hasPiece(loc, pieces)) {
							continue;
						}
					}
					Location nextMove = new Location(x - 2, y);
					super.addNextAvailableMoves(nextMove);
					this.castleMap.put(nextMove,  pieces.get(i));
				}
			}
		}
	}
}
