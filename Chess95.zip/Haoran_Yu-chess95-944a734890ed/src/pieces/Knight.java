package pieces;

import java.util.List;
/**
 * The class is to define knight pieces
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 *
 */
public class Knight extends Piece{
	/**
	 * Constructor of Knight
	 * 
	 * @param location This location 
	 * @param isBlack Check pieces is black or not
	 */
	public Knight(Location location, boolean isBlack) {
		super(location, isBlack, "N");
	}
	/**
	 * An abstract method to get all available location can move
	 */
	public void calculateAllAvailableMoves(List<Piece> pieces, List<Piece> enemyPieces) {
		super.clearNextAvailableMoves();
		int x = super.getLocation().getX();
		int y = super.getLocation().getY();
		findfirstMovesByDirection(x, y, 1, 2, pieces);
		findfirstMovesByDirection(x, y, 1, -2, pieces);
		findfirstMovesByDirection(x, y, -1, 2, pieces);
		findfirstMovesByDirection(x, y, -1, -2, pieces);
		findfirstMovesByDirection(x, y, 2, 1, pieces);
		findfirstMovesByDirection(x, y, 2, -1, pieces);
		findfirstMovesByDirection(x, y, -2, 1, pieces);
		findfirstMovesByDirection(x, y, -2, -1, pieces);
		
	}
	/**
	 * Finding next available location to move
	 * 
	 * @param x The value of x axis
	 * @param y The value of y axis
	 * @param xD Move direction on x axis
	 * @param yD Move direction on y axis
	 * @param pieces This team pieces
	 * @param enemyPieces The enemy team pieces
	 */
	private void findfirstMovesByDirection(int x, int y, int xD, int yD, List<Piece> pieces) {
		x += xD;
		y += yD;
		if(0 <= x && x < Location.BOARDSIZE && 0 <= y && y < Location.BOARDSIZE) {
			Location curLocation = new Location(x,y);
			super.addAttackRange(curLocation);
			if(hasPiece(curLocation, pieces)) {
				return;
			} else {
				super.addNextAvailableMoves(curLocation);
			}
		}
	}
}