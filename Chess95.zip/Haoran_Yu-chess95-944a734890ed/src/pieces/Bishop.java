package pieces;

import java.util.List;
/**
 * the class is to define bishop pieces
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public class Bishop extends Piece{
	/**
	 * Constructor of Bishop
	 * 
	 * @param location this location 
	 * @param isBlack check pieces is black or not
	 */
	public Bishop(Location location, boolean isBlack) {
		super(location, isBlack, "B");
	}
	/**
	 * an abstract method to get all available location can move
	 */
	public void calculateAllAvailableMoves(List<Piece> pieces, List<Piece> enemyPieces) {
		super.clearNextAvailableMoves();
		int x = super.getLocation().getX();
		int y = super.getLocation().getY();
		findAvailableMovesByDirection(x, y, 1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, 1, -1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, 1, pieces, enemyPieces);
		findAvailableMovesByDirection(x, y, -1, -1, pieces, enemyPieces);
		
	}
	/**
	 * finding next available location to move
	 * 
	 * @param x is x axis
	 * @param y is y axis
	 * @param xD move direction on x axis
	 * @param yD move direction on y axis
	 * @param pieces this team pieces
	 * @param enemyPieces enemy team pieces
	 */
	private void findAvailableMovesByDirection(int x, int y, int xD, int yD, List<Piece> pieces, List<Piece> enemyPieces) {
		x += xD;
		y += yD;
		while(0 <= x && x < Location.BOARDSIZE && 0 <= y && y < Location.BOARDSIZE) {
			Location curLocation = new Location(x,y);
			super.addAttackRange(curLocation);
			if(hasPiece(curLocation, pieces)) {
				break;
			} else {
				super.addNextAvailableMoves(curLocation);
				if(hasPiece(curLocation, enemyPieces)) {
					break;
				}
				
			}
			x += xD;
			y += yD;
		}
	}
}
