package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import board.Board;
/**
 * It is a main class
 * 
 * @author Haoran Yu
 * @author Zikang Xia
 *
 */
public class Main {
	/**
	 * The main method that we start the chess game loop.
	 * If one player win the game, the game will end.
	 * @param args The command-line arguments
	 * @throws IOException Throw IO exception
	 */
	public static void main(String[] args) throws IOException {
		
		// white make the first move, white = true, black = false
		boolean turn = true;
		boolean draw  = false;
		boolean nowDraw;
		//Start a new game
		Board board = new Board();
		while(true) {
			nowDraw = false;
			System.out.println(board.getBoardView());
			if(board.check(!turn)) {
				if(board.checkmate(!turn)) {
					printCheckMate(!turn);
					break;
				}
				System.out.println("\nCheck");
			}
			board.ResetEnpassant(turn);
			printTurn(turn);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String input = br.readLine().trim();
			if(draw && input.equals("draw")) {
				System.out.println("draw");
				break;
			}
			if(input.equals("resign")) {
				printWinMsg(!turn);
				break;
			}
			if(input.length() > 5 &&
					input.split("\\s+")[input.split("\\s+").length - 1].equals("draw?") ) {
				draw = true;
				input = input.substring(0, input.length() - 6);
				nowDraw = true;
			}
			if(board.move(input, turn)) {
				System.out.println("");
				if(!nowDraw) {
					draw = false;
				}
				if(board.isWin(turn)) {
					System.out.println(board.getBoardView());
					printWinMsg(turn);
					break;
				}
				turn = !turn;
			} 			
		}

	}
	/**
	 * To print win message after win
	 * 
	 * @param turn The boolean of turn, white = true, black = false
	 */
	public static void printWinMsg(boolean turn) {
		if(turn) {
			System.out.println("\nWhite wins");
		} else {
			System.out.println("\nBlack wins");
		}
	}
	/**
	 * To print win message after checking mate 
	 * 
	 * @param turn The boolean of turn, white = true, black = false
	 */
	public static void printCheckMate(boolean turn) {
		if(turn) {
			System.out.println("\nCheckmate");
			System.out.println("White wins");
		} else {
			System.out.println("\nCheckmate");
			System.out.println("Black wins");
		}
	}
	/**
	 * To print where input move
	 * 
	 * @param turn The boolean of turn, white = true, black = false
	 */
	public static void printTurn(boolean turn) { 
		if (turn) { 
			System.out.print("\nWhite's move: ");
		} 
		else { 
			System.out.print("\nBlack's move: "); 
		}
	}

}
